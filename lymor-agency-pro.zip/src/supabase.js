import { createClient } from "@supabase/supabase-js";
let client = null;
export function initSupabase() {
  const url = localStorage.getItem("supabase.url") || import.meta.env.VITE_SUPABASE_URL || "";
  const key = localStorage.getItem("supabase.anon") || import.meta.env.VITE_SUPABASE_ANON_KEY || "";
  if (!url || !key) return null;
  if (!client) client = createClient(url, key);
  return client;
}
export function getClient(){ return client; }