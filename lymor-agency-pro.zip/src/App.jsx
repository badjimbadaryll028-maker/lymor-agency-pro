import React, { useEffect, useMemo, useState } from "react";
import { Plus, X, Users, Trophy, Shield, Globe2, CalendarClock, Dumbbell } from "lucide-react";
import { initSupabase, getClient } from "./supabase";

const pageStyle = { background: '#0b0f1a', minHeight: '100vh', color: '#fff', fontFamily: 'Inter,system-ui,Segoe UI,Arial' };
const card = { border: '1px solid rgba(255,255,255,.1)', background: 'rgba(255,255,255,.05)', borderRadius: 16, padding: 16 };
const sports = ["Football","Basketball","Handball","Athlétisme","Rugby","Esport","Tennis","Autre"];

function useLocalStorage(key, initialValue){
  const [value,setValue] = useState(()=>{ try{ const v = localStorage.getItem(key); return v ? JSON.parse(v) : initialValue; }catch{return initialValue;} });
  useEffect(()=>{ try{ localStorage.setItem(key, JSON.stringify(value)); }catch{} },[key,value]);
  return [value,setValue];
}
const Input = (p)=> <input {...p} style={{...p.style, width:'100%', padding:'10px 12px', borderRadius:12, border:'1px solid rgba(255,255,255,.1)', background:'#0f1526', color:'#fff'}} />;
const Select = (p)=> <select {...p} style={{...p.style, width:'100%', padding:'10px 12px', borderRadius:12, border:'1px solid rgba(255,255,255,.1)', background:'#0f1526', color:'#fff'}} />;
const Textarea = (p)=> <textarea {...p} style={{...p.style, width:'100%', padding:'10px 12px', borderRadius:12, border:'1px solid rgba(255,255,255,.1)', background:'#0f1526', color:'#fff', minHeight:110}} />;
const Button = ({children, ...props})=> <button {...props} style={{ padding:'10px 16px', borderRadius:14, border:'1px solid rgba(255,255,255,.12)', background:'linear-gradient(135deg,#C084FC33,#20E5F633)', color:'#fff', fontWeight:700, display:'inline-flex', alignItems:'center', gap:8 }} >{children}</button>;

function Logo(){ return (<svg viewBox='0 0 520 120' style={{height:28}} fill='none' xmlns='http://www.w3.org/2000/svg'>
  <defs><linearGradient id='g' x1='0' y1='0' x2='520' y2='0'><stop stopColor='#20E5F6'/><stop offset='1' stopColor='#C084FC'/></linearGradient></defs>
  <path fill='url(#g)' d='M18 20h22v64h44v16H18V20zm128 80h-22V20h22l30 41 30-41h22v80h-22V57l-30 40-30-40v43zm162-80c31 0 52 20 52 40s-21 40-52 40-52-20-52-40 21-40 52-40zm0 18c-19 0-30 13-30 22s11 22 30 22 30-13 30-22-11-22-30-22zm144-18-53 96h-23l18-32-35-64h24l23 43 23-43h23z'/>
  <text x='340' y='105' fill='#9ba3b5' fontFamily='Inter, system-ui, sans-serif' fontSize='20' letterSpacing='2'>AGENCY</text>
</svg>);}

function PlayerCard({ p }){
  return (
    <div style={{...card}}>
      <div style={{display:'flex', gap:12, alignItems:'center'}}>
        <div style={{height:64, width:64, borderRadius:16, border:'1px solid rgba(255,255,255,.1)', display:'grid', placeItems:'center', background:'linear-gradient(135deg,rgba(0,255,255,.2),rgba(255,0,255,.2))'}}>
          {p.image ? <img src={p.image} style={{height:64,width:64,objectFit:'cover',borderRadius:16}}/> : <Users size={24} />}
        </div>
        <div style={{minWidth:0}}>
          <div style={{fontWeight:700, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'}}>{p.name}</div>
          <div style={{opacity:.8, fontSize:14}}>{p.sport} • {p.position||'—'}</div>
          <div style={{opacity:.6, fontSize:12}}>{p.club || 'Sans club'}</div>
        </div>
      </div>
    </div>
  );
}

function PlayerForm({ onSubmit, onCancel, initial }){
  const [form,setForm] = useState(initial || { id: crypto.randomUUID(), createdAt:new Date().toISOString(), name:'', sport:'Football', position:'', club:'', nationality:'', birth:'', email:'', phone:'', height:'', weight:'', notes:'', image:'' });
  const handle = (k)=> (e)=> setForm(f=> ({...f, [k]: e.target.value}));
  return (
    <form onSubmit={(e)=>{e.preventDefault(); onSubmit(form);}} style={{display:'grid', gap:12}}>
      <div style={{display:'grid', gap:12, gridTemplateColumns:'1fr 1fr'}}>
        <div><label>Nom</label><Input value={form.name} onChange={handle('name')} required/></div>
        <div><label>Sport</label><Select value={form.sport} onChange={handle('sport')}>{sports.map(s=><option key={s}>{s}</option>)}</Select></div>
        <div><label>Poste</label><Input value={form.position} onChange={handle('position')} /></div>
        <div><label>Club</label><Input value={form.club} onChange={handle('club')} /></div>
        <div><label>Nationalité</label><Input value={form.nationality} onChange={handle('nationality')} /></div>
        <div><label>Naissance</label><Input type='date' value={form.birth} onChange={handle('birth')} /></div>
        <div><label>Email</label><Input type='email' value={form.email} onChange={handle('email')} /></div>
        <div><label>Téléphone</label><Input value={form.phone} onChange={handle('phone')} /></div>
        <div><label>Taille (cm)</label><Input value={form.height} onChange={handle('height')} /></div>
        <div><label>Poids (kg)</label><Input value={form.weight} onChange={handle('weight')} /></div>
      </div>
      <div><label>Notes</label><Textarea value={form.notes} onChange={handle('notes')} /></div>
      <div><label>Photo (si Supabase actif)</label><input type='file' accept='image/*' onChange={async (e)=>{
        const file = e.target.files?.[0]; if(!file) return;
        const supa = getClient(); if(!supa){ alert('Active Supabase dans Config pour l\'upload'); return; }
        const path = `${form.id}/${Date.now()}_${file.name}`;
        const { error } = await supa.storage.from('player-photos').upload(path, file, { upsert: true });
        if(error){ alert('Upload KO'); console.error(error); return; }
        const { data } = supa.storage.from('player-photos').getPublicUrl(path);
        setForm(f=> ({...f, image: data?.publicUrl || ''}));
      }} /></div>
      <div style={{display:'flex', justifyContent:'end', gap:8}}>
        <button type='button' onClick={onCancel} className='btn'>Annuler</button>
        <button type='submit' className='btn primary'>Enregistrer</button>
      </div>
    </form>
  );
}

function Chat({ role }){
  const [text,setText] = useState('');
  const [msgsLocal,setMsgsLocal] = useLocalStorage('lymor.chat',[]);
  const [msgs,setMsgs] = useState([]);

  useEffect(()=>{
    const supa = initSupabase();
    if(supa){
      (async ()=>{
        const { data } = await supa.from('messages').select('*').order('ts',{ascending:true});
        setMsgs(data || []);
        const ch = supa.channel('realtime:messages').on('postgres_changes',{event:'INSERT',schema:'public',table:'messages'}, (payload)=>{
          setMsgs(prev => [...prev, payload.new]);
        }).subscribe();
        return ()=> supa.removeChannel(ch);
      })();
    } else {
      setMsgs(msgsLocal);
    }
  },[]);

  useEffect(()=>{ if(!getClient()) setMsgs(msgsLocal); },[msgsLocal]);

  async function send(){
    const t = text.trim(); if(!t) return;
    const m = { id: crypto.randomUUID(), sender: role, text: t, ts: new Date().toISOString() };
    if(getClient()){
      const { error } = await getClient().from('messages').insert(m);
      if(error) console.error(error);
    } else {
      setMsgsLocal(prev => [...prev, m]);
    }
    setText('');
  }

  return (
    <div style={{...card}}>
      <div style={{height:240, overflow:'auto', display:'grid', gap:8}}>
        {(msgs||[]).map(m => (
          <div key={m.id} style={{textAlign: m.sender==='owner' ? 'right':'left'}}>
            <div style={{display:'inline-block', maxWidth:'80%', background:m.sender==='owner'?'rgba(192,132,252,.25)':'rgba(255,255,255,.07)', border:'1px solid rgba(255,255,255,.12)', borderRadius:16, padding:'8px 10px'}}>
              <div style={{opacity:.8, fontSize:12, marginBottom:2}}>{m.sender.toUpperCase()}</div>
              <div>{m.text}</div>
              <div style={{opacity:.6, fontSize:10, marginTop:4}}>{new Date(m.ts).toLocaleString()}</div>
            </div>
          </div>
        ))}
      </div>
      <div style={{display:'flex', gap:8, marginTop:8}}>
        <Input value={text} onChange={(e)=> setText(e.target.value)} placeholder='Écrire un message…'/>
        <button className='btn' onClick={send}>Envoyer</button>
      </div>
      {!getClient() && <div style={{opacity:.7, fontSize:12, marginTop:6}}>Mode local (active Supabase dans Config pour le temps réel).</div>}
    </div>
  );
}

export default function App(){
  const [players,setPlayers] = useLocalStorage('agency.players',[]);
  const [query,setQuery] = useState('');
  const [sportFilter,setSportFilter] = useState('Tous');
  const [openForm,setOpenForm] = useState(false);
  const [isAuthed,setIsAuthed] = useState(()=> !!localStorage.getItem('lymor.authed'));
  const [role,setRole] = useState(()=> localStorage.getItem('lymor.role') || 'client');
  const [showAuth,setShowAuth] = useState(false);
  const [showConfig,setShowConfig] = useState(false);

  const filtered = useMemo(()=>{
    const q = query.trim().toLowerCase();
    return players.filter(p=>{
      const hay = `${p.name} ${p.sport} ${p.position} ${p.club}`.toLowerCase();
      const okQ = q ? hay.includes(q) : true;
      const okS = sportFilter==='Tous' ? true : p.sport===sportFilter;
      return okQ && okS;
    });
  },[players,query,sportFilter]);

  async function savePlayer(data){
    setPlayers(prev => {
      const exists = prev.some(x=>x.id===data.id);
      return exists ? prev.map(x => x.id===data.id ? data : x) : [data, ...prev];
    });
    if(getClient()){
      const { error } = await getClient().from('players').upsert(data, { onConflict: 'id' });
      if(error) console.error(error);
    }
    setOpenForm(false);
  }

  useEffect(()=>{ initSupabase(); },[]);

  return (
    <div style={pageStyle}>
      <header style={{position:'sticky', top:0, background:'rgba(11,15,26,.7)', borderBottom:'1px solid rgba(255,255,255,.1)', backdropFilter:'blur(10px)', zIndex:10}}>
        <div className='container' style={{display:'flex', justifyContent:'space-between', alignItems:'center', padding:'12px 0'}}>
          <div style={{display:'flex', alignItems:'center', gap:8}}><Logo /><span className='sr-only'>LYMOR Agency</span></div>
          <nav style={{display:'flex', gap:16, alignItems:'center', fontSize:14}}>
            <a href='#services' style={{opacity:.9}}>Services</a>
            <a href='#roster' style={{opacity:.9}}>Roster</a>
            <a href='#client' style={{opacity:.9}}>Espace client</a>
            {(isAuthed && (role==='owner'||role==='staff')) && <button className='btn' onClick={()=> setOpenForm(true)}><Plus size={16}/> Ajouter</button>}
            {isAuthed ? (<>
              {role==='owner' && <button className='btn' onClick={()=> setShowConfig(true)}>Configurer Supabase</button>}
              <button className='btn' onClick={()=> { localStorage.removeItem('lymor.authed'); setIsAuthed(false); }}>Se déconnecter</button>
            </>) : (<button className='btn' onClick={()=> setShowAuth(true)}>Se connecter</button>)}
          </nav>
        </div>
      </header>

      <section className='container' style={{textAlign:'center', padding:'40px 0'}}>
        <div style={{display:'inline-block', padding:'6px 10px', border:'1px solid rgba(255,255,255,.12)', borderRadius:999, fontSize:12, opacity:.9}}>Agence de management & accompagnement 360°</div>
        <h1 style={{fontSize:40, margin:'14px 0'}}>Nous révélons et protégeons <span style={{background:'linear-gradient(90deg,#20E5F6,#C084FC)', WebkitBackgroundClip:'text', color:'transparent'}}>le potentiel des athlètes</span></h1>
        <p style={{opacity:.85, maxWidth:800, margin:'0 auto'}}>Management de carrières pour footballeurs, basketteurs, sportives & sportifs de haut niveau. Négociation de contrats, stratégie d'image, performance & bien‑être.</p>
      </section>

      <section id='services' className='container' style={{padding:'10px 0 20px'}}>
        <h2>Services clés</h2>
        <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12}}>
          {[
            { title: 'Management de carrière', desc: 'Accompagnement stratégique, choix de clubs.', Icon: Shield },
            { title: 'Négociation & contrats', desc: 'Transferts, primes, droits à l\'image.', Icon: Trophy },
            { title: 'Image & partenariats', desc: 'Personal branding, sponsors, médias.', Icon: Users },
            { title: 'Performance', desc: 'Prépa physique, nutrition, data.', Icon: Dumbbell },
            { title: 'Relocalisation', desc: 'Logement, administratif, intégration.', Icon: Globe2 },
            { title: 'After‑career', desc: 'Formation, reconversion.', Icon: CalendarClock }
          ].map(({title,desc,Icon})=>(
            <div key={title} style={card}><div style={{display:'flex', alignItems:'center', gap:8, fontWeight:600}}><Icon size={16}/> {title}</div><p style={{opacity:.85, fontSize:14, marginTop:6}}>{desc}</p></div>
          ))}
        </div>
      </section>

      <section id='roster' className='container' style={{padding:'20px 0'}}>
        <h2>Nos talents / Base joueurs</h2>
        <Roster filteredHook={{filtered, setQuery, setSportFilter}} setOpenForm={setOpenForm} />
      </section>

      <section id='client' className='container' style={{padding:'10px 0 40px'}}>
        <h2>Espace client</h2>
        <Chat role={role} />
      </section>

      <section id='contact' className='container' style={{padding:'20px 0 50px'}}>
        <h2>Contact</h2>
        <form onSubmit={(e)=>{ e.preventDefault(); alert('Merci ! (démo)'); e.target.reset(); }} style={{display:'grid', gap:12, maxWidth:520}}>
          <div style={{display:'grid', gap:12, gridTemplateColumns:'1fr 1fr'}}>
            <Input placeholder='Nom' required/><Input type='email' placeholder='Email' required/>
          </div>
          <Input placeholder='Sujet'/><Textarea placeholder='Votre message' required/>
          <button className='btn primary' type='submit'>Envoyer</button>
        </form>
      </section>

      {openForm && (
        <div style={{position:'fixed', inset:0, background:'rgba(0,0,0,.6)', display:'grid', placeItems:'center'}}>
          <div style={{...card, width:'min(720px,92%)'}}>
            <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
              <h3>Ajouter / Modifier un joueur</h3>
              <button onClick={()=> setOpenForm(false)} style={{background:'transparent', border:0, color:'#fff'}}><X size={18}/></button>
            </div>
            <PlayerForm onCancel={()=> setOpenForm(false)} onSubmit={savePlayer} />
          </div>
        </div>
      )}

      {/* Auth */}
      {showAuth && (
        <div style={{position:'fixed', inset:0, background:'rgba(0,0,0,.6)', display:'grid', placeItems:'center'}}>
          <div style={{...card, width:'min(520px,92%)'}}>
            <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
              <h3>Se connecter</h3>
              <button onClick={()=> setShowAuth(false)} style={{background:'transparent', border:0, color:'#fff'}}><X size={18}/></button>
            </div>
            <form onSubmit={(e)=>{
              e.preventDefault();
              const roleSel = e.currentTarget.elements.namedItem('role').value;
              const pass = e.currentTarget.elements.namedItem('pwd').value;
              const key = roleSel==='owner' ? 'lymor.owner.pass' : (roleSel==='staff' ? 'lymor.staff.pass' : 'lymor.client.pass');
              const stored = localStorage.getItem(key)||'';
              if(stored && pass===stored){
                localStorage.setItem('lymor.authed','1'); localStorage.setItem('lymor.role', roleSel);
                setRole(roleSel); setIsAuthed(true); setShowAuth(false);
              } else { alert('Identifiants incorrects ou mot de passe non défini.'); }
            }} style={{display:'grid', gap:12}}>
              <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:10}}>
                <label><input type='radio' name='role' value='owner' defaultChecked/> Propriétaire</label>
                <label><input type='radio' name='role' value='staff'/> Équipe</label>
                <label><input type='radio' name='role' value='client'/> Client</label>
              </div>
              <Input name='pwd' type='password' placeholder='Mot de passe' required/>
              <div style={{display:'flex', justifyContent:'space-between'}}>
                <button className='btn' type='button' onClick={()=> setShowAuth(false)}>Annuler</button>
                <button className='btn primary' type='submit'>Entrer</button>
              </div>
              <div style={{opacity:.7, fontSize:12}}>Astuce : définis d’abord les mots de passe via “Définir mots de passe”.</div>
            </form>
          </div>
        </div>
      )}

      {/* Config (owner only) */}
      {showConfig && (
        <div style={{position:'fixed', inset:0, background:'rgba(0,0,0,.6)', display:'grid', placeItems:'center'}}>
          <div style={{...card, width:'min(600px,92%)'}}>
            <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
              <h3>Configurer Supabase</h3>
              <button onClick={()=> setShowConfig(false)} style={{background:'transparent', border:0, color:'#fff'}}><X size={18}/></button>
            </div>
            <form onSubmit={(e)=>{
              e.preventDefault();
              const url = e.currentTarget.elements.namedItem('url').value;
              const anon = e.currentTarget.elements.namedItem('anon').value;
              localStorage.setItem('supabase.url', url);
              localStorage.setItem('supabase.anon', anon);
              initSupabase();
              alert('Clés enregistrées. Recharge la page.');
            }} style={{display:'grid', gap:12}}>
              <Input name='url' placeholder='SUPABASE URL (https://...supabase.co)' defaultValue={localStorage.getItem('supabase.url')||''}/>
              <Textarea name='anon' placeholder='SUPABASE ANON KEY' defaultValue={localStorage.getItem('supabase.anon')||''}/>
              <div style={{display:'flex', justifyContent:'flex-end', gap:8}}>
                <button className='btn' type='button' onClick={()=> setShowConfig(false)}>Annuler</button>
                <button className='btn primary' type='submit'>Enregistrer</button>
              </div>
              <div style={{opacity:.7, fontSize:12}}>Crée un bucket public “player-photos” pour les uploads.</div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function Roster({ filteredHook, setOpenForm }){
  const { filtered, setQuery, setSportFilter } = {
    filtered: filteredHook.filtered ?? [],
    setQuery: filteredHook.setQuery ?? (()=>{}),
    setSportFilter: filteredHook.setSportFilter ?? (()=>{})
  };
  return (
    <div>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', gap:8, flexWrap:'wrap'}}>
        <div style={{display:'flex', gap:8, alignItems:'center'}}>
          <Input placeholder='Rechercher…' onChange={(e)=> setQuery(e.target.value)} />
          <Select onChange={(e)=> setSportFilter(e.target.value)}>
            <option>Tous</option>{sports.map(s=> <option key={s}>{s}</option>)}
          </Select>
        </div>
        <div style={{opacity:.8, fontSize:12}}>{filtered.length} joueurs</div>
      </div>
      {filtered.length===0 ? <div style={{opacity:.8, marginTop:12}}>Aucun joueur pour l’instant.</div> :
        <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginTop:12}}>
          {filtered.map(p=> <PlayerCard key={p.id} p={p} />)}
        </div>
      }
    </div>
  );
}
